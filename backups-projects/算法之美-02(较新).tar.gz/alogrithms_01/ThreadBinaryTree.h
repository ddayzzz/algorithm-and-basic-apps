#pragma once
#include "stdafx.h"
//#include "BinaryTree.h"
template<typename T>
class ThreadBinaryTreeNode //��ʵ����ʹ�ü̳й�ϵ
{
	typedef T DataType;
	typedef ThreadBinaryTreeNode<DataType> NodeType;
	typedef NodeType *Node;
public:
	ThreadBinaryTreeNode() :leftchild(nullptr), rightchild(nullptr) {}
	ThreadBinaryTreeNode(DataType da, Node l = nullptr, Node r = nullptr) :leftchild(l), rightchild(r), data(da) {}
	//��ȡ
	DataType &getData()
	{
		return data;
	}
	//���������
	void setLeftchild(Node l) { leftchild = l; }
	//�����Ҷ���
	void setRightchild(Node r) { rightchild = r; }
	//��ȡ�����
	Node getLeftchild() { return leftchild; }
	//��ȡ�Ҷ���
	Node getRightchild() { return rightchild; }
	//�������� Node�ɹ������ͷ�
	~ThreadBinaryTreeNode() {}
	
private:
	Node leftchild;
	Node rightchild;
	bool leftThread;
	bool rightThread;
	DataType data;
};
template<typename T> class ThreadBinaryTreeList
{
	typedef T DataType;
	typedef ThreadBinaryTreeNode<T> NodeType;
	typedef NodeType *Node;
public:
	ThreadBinaryTreeList(DataType da):root(new NodeType(da)){}
	//����
	Node &getRoot();
	void insert_left(Node parent);
	void insert_right(Node parent);
	void erase_left(Node parent);
	void erase_right(Node parent);
	void clear();
private:
	Node root;
};