#pragma once
#include "stdafx.h"
#include <list>
#include <iostream>
#include "StackList.hpp"
#include "Queue.hpp"
#include <string>
#include <algorithm>
using namespace std;
 LinkQueueList<int>;
//ͨ�õĺ���
int max1(int a, int b) { return (a > b ? a : b); }
//Լɪ������
//�ⷨһ��listģ��
int jos(int tobedel,int tot)
{
	//tobedel��ɾ���ı������ ��1��ʼ
	//toto��������
	std::list<int> list;
	
	int n = tot;
	for (int i = 1; i <= n; ++i)
		list.insert(list.end(),i);
	std::list<int>::iterator it = list.begin();
	while (list.size() > 1)
	{
		for (int i = 1; i < tobedel; ++i)
		{
			if (++it == list.end())
			{
				it = list.begin();
			}

		}
		std::list<int>::iterator del = it;
		if (++it == list.end())
		{
			it = list.begin();
		}
		list.erase(del);
	}
	return *(it);
}
//�ⷨ������ѧ����
int jos2(int tobedel,int total)
{
	int x1=0;
	for (int i = 2; i <= total; ++i)
	{
		x1 = (x1 + tobedel) % i;
	}
	return x1+1;
}
//ħ��ʦ��������
void realease_poker()
{
	std::list<int> poker;
	for (int i = 1; i <= 13; ++i)
	{
		poker.push_back(0);
	}
	//poker[0]='1';
	auto it = poker.begin();
	*it = 1;
	for (int i = 2; i < 14; ++i)//ע���ǴӴӺ���1��ʼ��Ҳ����index=2
	{
		for (int j = 0; j < i; ++j)
		{
			it++;
			if (it == poker.end())
			{
				it = poker.begin();
			}
			
			if (*it != 0)
				--j;
		}
		*it= i;

		if (it == poker.end())
		{
			it = poker.begin();
		}
	}
	for (auto i = poker.cbegin(); i != poker.cend(); ++i)
		cout << *i << " ";
}
//�������� ��д�Ľⷨ1
void latin_pattern(int n)
{
	std::list<int> latin;
	int jieshu = 1;
	int insernum = 1;
	for (int i = 1; i <= n*n; ++i)
	{
		latin.push_back(insernum);
		int flag = i % n;
		if (flag == 0)
		{
			jieshu++;
			insernum = jieshu;
			continue;
		}
		if (insernum >= n)
		{
			insernum = 1;
		}
		else
		{
			++insernum;
		}

	}
	auto i = latin.cbegin();
	for (int o = 1; o <= n*n; ++o)
	{
		if (o % n)
		{
			cout <<setw(3)<< *i++ << " ";
		}
		else
		{
			cout <<setw(3)<< *i++ << "\n";
		}
	}
}
void latin_pattern_1(int n)
{
	std::list<int> latin;
	for (int i = 1; i <= n; ++i)
		latin.push_back(i);
	auto it = latin.begin();
	auto last = --latin.end();
	int cnt = 1;

	auto beg = it;
	for (int i = 1; i <= n; ++i)
	{
		while (cnt <= n)
		{
			if (beg != last)
			{
				cout << *beg++ << " ";
			}
			else
			{
				cout << *beg << " ";
				beg = latin.begin();
			}
			if (cnt++ == n)
				cout << endl;
		}
		cnt = 1;
		beg = latin.begin();
		for (int j = 1; j <= i; ++j)
		{
			++beg;
		}
	}
	
}
//�������Ǽ��ܷ�����
//�ⷨ1 ����
char* Vigenere_classfiy( char *tobedone, const int *key, int sizeoftobedone, int sizeofkey)
{
	if (sizeofkey <= sizeoftobedone)
	{
		int i = 0;
		int j = 0;
		for (; j < sizeoftobedone; ++j)
		{
			//����ƫ�Ƶ�λ��
			int ascii;
			if (i >= sizeofkey)
			{
				i = 0;
			}
			ascii = tobedone[j] + key[i++];
			if (ascii > 'z')
			{
				ascii = 'a' + ascii - 'z'-1;
			}
			tobedone[j] = ascii;
		}
		
	}
	return tobedone;
}
//����ƥ������
bool Match_kuohao(const char *c, int sz)
{
	StackList<char> li;
	for (int i = 1; i <= sz+1; ++i)
	{
		switch (c[i-1])
		{
		case '(':
			li.Push(c[i - 1]);
			break;
		case ')':
			if(!li.isEmpty())
			{
				li.Pop();
				break;
			}
			return !li.isEmpty();
		case '\0':
			return li.isEmpty();

		}
	}
return false;
}
//���������
int MaxSubQueue_Value(const int *seq, int i,int e)
{
	if (i == e)
	{
		if (seq[i] > 0)
			return seq[i];
		else
			return 0;
	}
	int mid = (e + i) / 2;
	int left = MaxSubQueue_Value(seq, i, mid);
	int right = MaxSubQueue_Value(seq, mid + 1, e);
	int leftsum = 0; int maxleftsum = 0;
	int rightsum = 0; int maxrightsum = 0;
	for (int h = mid; h >= i; --h)
	{
		leftsum += seq[h];
		if (leftsum > maxleftsum)maxleftsum = leftsum;
	}
	for (int h = mid+1; h <= e; ++h)
	{
		rightsum += seq[h];
		if (rightsum > maxrightsum)maxrightsum = rightsum;
	}
	return max1(max1(maxleftsum, maxrightsum), maxleftsum + maxrightsum);
}
//�������
//�������� ���ڽ���
void show_exchange_queue(LinkQueueList<int> &old,LinkQueueList<int> &newone,int jieshu,int maxjieshu)
{
	old.makeEmpty();
	for (int i = maxjieshu - jieshu; i >= 1; --i)
	{
		std::cout << "   ";
	}
	while (!newone.isEmpty())
	{
		int dep = newone.DeQueue();
		old.EnQueue(dep);
		std::cout << std::setw(6) << dep;
	}
	newone.makeEmpty();
	std::cout << std::endl;
}
void Yanghui_Triangle(int n)
{
	LinkQueueList<int> ori,curr;
	int ini = 1;
	int precnt = 0; int nextcnt = 1;
	for (int i = 1; i <= n; ++i)
	{
		/* �ҵĴ���ʵ��
		for (int u = 1; u <= i; ++u)
		{
			if (u == 1) { precnt = 0; nextcnt = 1; if (!ori.isEmpty()) { ori.DeQueue(); } //����ж����ڴ����ӵڶ��׿�ʼ���ϴζ��еļ�������
			}
			else if (u == i) { nextcnt = 0; }
			curr.EnQueue(precnt + nextcnt);
			int temp = nextcnt;
			if (!ori.isEmpty())
			{
				nextcnt = ori.DeQueue();
			}
			precnt = temp;
			
		}
		*/
		curr.EnQueue(ini);
		while (!ori.isEmpty())
		{
			int h = ori.DeQueue();
			if (ori.isEmpty() == false)
			{
				h += ori.GetFront();
				curr.EnQueue(h);
			}
			if (ori.isEmpty())
				curr.EnQueue(h);
		}
		show_exchange_queue(ori, curr,i,n);

	}
}
//������� ����ⷨ
void display(int *p,int curr, int maxline)
{
	for (int u = maxline; u > curr; --u)
		std::cout << "   ";
	for (int i = 1; i <= curr; ++i)
		std::cout << std::setw(6) << p[i - 1];
	std::cout << std::endl;
}
void Yanghui_Triangle_array(int n)
{
	if (n >= 1)
	{
		int **ptr = new int*[n];
		int **start = ptr;
		for (int j = 1; j <= n; ++j)
		{
			*ptr++ = new int[j];
		}
		//�ڴ�������
		
		for (int i = 1; i <= n; ++i)
		{
			(*(start + i - 1))[0] = 1;
			int lcnt = 0;
			int rcnt = 1;
			
			for (int u = 2; u <= i; ++u)
			{
				if (u <= i - 1)
				{
					int tem = rcnt;
					rcnt = (*(start + i - 2))[u - 1];
					lcnt = tem;
				}
				else
				{
					lcnt = rcnt;
					rcnt = 0;
				}
				(*(start + i - 1))[u - 1] = lcnt + rcnt;
			}
			display(start[i - 1], i, n);
		}
		for (int u = 1; u <= n; ++u)
			delete start[u-1];
		delete start;
	}
	
}
//ģ���ڴ�ҳ
#include <queue>
//FIFO����
bool ExitOrNot(int num, std::queue<int> que)
{
	while (!que.empty())
	{
		if (que.front() == num)
			return true;
		else
			que.pop();
	}
	return false;
}
void Queyezhongduan(int *p, int size)
{
	using std::queue;
	queue<int> mem;
	int queyecnt = 0;
	for (int i = 0; i < size; ++i)
	{
		if (mem.size() < 3)
		{
			mem.push(p[i]);
			++queyecnt;//�״������ڴ�
		}
		else
		{
			if (ExitOrNot(p[i], mem))
			{

			}
			else
			{
				mem.pop();
				mem.push(p[i]);
				queyecnt++;
			}
			int sz = mem.size();
			while (sz > 0)
			{
				cout << mem.front() << " ";
				int tmpvalue = mem.front();
				mem.pop();
				mem.push(tmpvalue);
				--sz;
			}
			cout << endl;
		}
	}
	std::cout << "ʹ��FIFO���� �������ڴ�ȱҳ " << queyecnt << " ��\n";
}
//LRU����
void Queue_memory_pagemgr_LRU(int *p, int size)
{
	std::queue<int> mem;
	int queye = 0;
	for (int i = 0; i < size; ++i)
	{
		if (mem.size() < 3)
		{
			mem.push(p[i]);
			++queye;
		}
		else
		{
			if (ExitOrNot(p[i], mem))
			{
				if (p[i] == mem.front())
				{
					mem.pop();
					mem.push(p[i]);
				}
				else
				{
					queue<int> tempfor;//������ʱ����pop����������
					int sz = mem.size();//��¼û��ɾ��ǰ��mem��С
					while (!mem.empty())
					{
						int getit = mem.front();//��ȡ��ͷ
						if (getit == p[i])
						{
							mem.pop();
							int need = sz - tempfor.size()-1;//��������������֮����Ҫѭ���Ĵ���
							//���ǰ��ڴ�ҳ���ҵ����Ǹ��ڴ�֮ǰ������ѹ�뵽mem 
							while (!tempfor.empty())
							{
								mem.push(tempfor.front());
								tempfor.pop();
							}
							//����ʱ�ڴ�֮ǰ���ڴ��ڶ�β�� ������Ҫͨ���ҵ��ڴ�֮���β��Ԫ�ش�С��ѭ�� �ɶ�β��Ԫ�ظĵ���ͷ
							while (need > 0)
							{
								int tmp = mem.front();
								mem.pop();
								mem.push(tmp);
								--need;
							}
							mem.push(p[i]);
							break;
						}
						else
						{
							tempfor.push(getit);
							mem.pop();
						}
					}
				}
			}
			else
			{
				mem.pop();
				mem.push(p[i]);
				++queye;
			}
			int sz = mem.size();
			while(sz > 0)
			{
				int m = mem.front();
				cout << m << " ";
				mem.pop();
				mem.push(m);
				--sz;
			}
			cout << endl;
		}
	}
	cout << "ʹ��LRU����ȱҳ���� " << queye << " ��" << endl;
}
//���㹤�ߺ��� 
//���ֵķֽ⣨int to char[])
std::string InttoString(int tmp)
{
	int weight = 10;
	std::string s;
	while (tmp)
	{
		int a = tmp % weight;
		a = a / (weight / 10);
		s.insert( s.begin(),char(a + 48));
		tmp = tmp - a*(weight/10);
		weight *= 10;
		
	}
	return s;
}
int makeZHENGQI_ANDREVERSE(std::string &s1, std::string &s2)
{
	int maxcnt = (s1.size() > s2.size() ? s1.size() : s2.size()) + 1;
	if (s1.size() > s2.size())
	{
		//s2
		int cnt = s1.size() - s2.size();
		for (; cnt > 0; --cnt)
		{
			s2.insert(s2.begin(), '0');
		}
	}
	else
	{

		if (s2.size() > s1.size())
		{
			//s1
			int cnt = s2.size() - s1.size();
			for (; cnt > 0; --cnt)
			{
				s1.insert(s1.begin(), '0');
			}
		}

	}
	//��
	/*
	int cnt = maxcnt - 1;
	int li = cnt - 1;
	cnt /= 2;
	int i = 0;
	while (cnt > 0)
	{
		int t = s1[i];
		s1[i] = s1[li];
		s1[li] = t;
		t = s2[i];
		s2[i] = s2[li];
		s2[li] = t;
		++i;
		--li;
		--cnt;
	}
	*/
	//ʹ�ñ�׼���㷨
	std::reverse(s1.begin(), s1.end());
	std::reverse(s2.begin(), s2.end());
	s1.push_back('0');
	s2.push_back('0');
		return maxcnt;
}
std::string bigadd(std::string s1, std::string s2)
{
	std::string res;
	int max = makeZHENGQI_ANDREVERSE(s1, s2);
	int flag = 0;
	for (int i = 0; i < max; ++i)
	{
		int add = s1[i]-48 + s2[i]-48;
		add = add + flag;
		res.push_back(add % 10 + 48);
		flag = add / 10;
	}
	if (res.back() == '0')
	{
		res.pop_back();
	}
	std::reverse(res.begin(), res.end());
	return res;
}
std::string bigmultiply(std::string s1, std::string s2)
{
	std::reverse(s1.begin(), s1.end());
	std::reverse(s2.begin(), s2.end());
	std::string res;
	int maxsz = s1.size() + s2.size();
	for (int s = 0; s < maxsz; ++s) res.push_back('0');
	int i, j;
	for (i = 0; i < s1.size(); ++i)
	{
		int addflag = 0;
		int multiplyflag = 0;
		for (j = 0; j < s2.size(); ++j)
		{
			int cheng = (s1[i] - '0')*(s2[j] - '0');
			cheng = cheng + multiplyflag;
			int add = res[i + j] - '0' + cheng % 10 + addflag;
			res[i + j] = add % 10 + '0';
			addflag = add / 10;
			multiplyflag = cheng / 10;
		}
		res[i + j] = res[i + j] - '0' + multiplyflag +addflag+ '0';
	}
	if (res.back() == '0')
	{
		res.pop_back();
	}
	std::reverse(res.begin(), res.end());
	return res;
}
//��ʾ�׳�
void display_factorize(int s)
{
	std::vector<string> str;
	for (int i = 1; i <= s; ++i)
	{
		if (i == 1)
		{
			str.push_back(string("1"));
			cout << "1!=1" << endl;
		}
		else
		{
			string tmp = bigmultiply(str[i - 2], InttoString(i));
			str.push_back(tmp);
			cout << i << "!=" << tmp << endl;
		}
	}
}
void output_factorize(int s)
{
	std::vector<string> str;
	std::ofstream of("E:\\FACT.TXT");
	for (int i = 1; i <= s; ++i)
	{
		if (i == 1)
		{
			str.push_back(string("1"));
			of << "1!=1" << endl;
		}
		else
		{
			string tmp = bigmultiply(str[i - 2], InttoString(i));
			str.push_back(tmp);
			of << i << "!=" << tmp << endl;
		}
	}
}
//��ŵ������

void Hannuo_display(int n, char from, char dest)
{

	cout << "����" << n << "��" <<from<< "�ƶ���" << dest <<" "<<endl;

}
void Hannuo(int n, char from, char via, char dest)
{
	if (n == 1)
	{
		Hannuo_display(1, from, dest);
	}
	else
	{
		Hannuo(n - 1, from, dest, via);
		Hannuo_display(n, from, dest);
		Hannuo(n - 1, via, from, dest);
	}
}
//��Ⱦ������
struct Cell
{
	int Isvirus;
	bool bechecked=false;
};
class CellsGroup
{
public:
	//celllist �Ǳ�ʾϸ��״̬�����飬nb��ʾϸ����ı߳�����
	CellsGroup(int celllist[6][6], int n) :units(n)
	{
		for (int i = 0; i < n; ++i)
		{
			std::vector<Cell> tmp;
			for (int j = 0; j < n; ++j)
			{
				Cell c;
				c.Isvirus = celllist[i][j];
				tmp.push_back(c);
			}
			cellsgroup.push_back(tmp);
		}

	}
	//�������ʾԭʼ����
	void display_grid()
	{
		for (auto iter = cellsgroup.cbegin(); iter != cellsgroup.cend(); ++iter)
		{
			for (auto b = iter->cbegin(); b != iter->cend(); ++b)
			{
				cout << b->Isvirus << " ";
			}
			cout << endl;

		}
	}
	//��������ѱ����ķ��ظ�Ⱦϸ������
	void display_grid_check()
	{
		for (auto iter = cellsgroup_check.cbegin(); iter != cellsgroup_check.cend(); ++iter)
		{
			for (auto b = iter->cbegin(); b != iter->cend(); ++b)
			{
				if (b->bechecked == true)
				{
					cout << std::setw(3) <<"+"<< b->Isvirus;
				}
				else
				{
					cout << std::setw(3) << b->Isvirus;
				}
			}
			cout << endl;

		}
	}
	void find_virus(int x, int y)
	{
		cellsgroup_check = cellsgroup;//����һ���µĸ���
		numberofVirus_check = 0;//��Ⱦ����Ϊ0
		do_findvirus(x, y);//��ʼ���
	}
	void do_findvirus(int x, int y)
	{
		if (x < 0 || y<0 || x>=units || y >=units|| cellsgroup_check[x][y].Isvirus==0)//�˳�����
		{
			return;
		}
		if (cellsgroup[x][y].Isvirus == 1)//ԭʼ���ݵ�λ���Ƿ�Ϊ��Ⱦ��ϸ�� ����Ǿͼ����Χ
		{
			if (cellsgroup_check[x][y].bechecked == false)//��ֹ�ظ�����
			{
				numberofVirus_check++;
				cellsgroup_check[x][y].Isvirus = 1;
				cellsgroup_check[x][y].bechecked = true;
				do_findvirus(x - 1, y - 1);//LEFT UP
				do_findvirus(x - 1, y);//UP
				do_findvirus(x - 1, y + 1);//right up
				do_findvirus(x, y - 1);//left
				do_findvirus(x, y + 1);//right
				do_findvirus(x + 1, y - 1);//left down
				do_findvirus(x + 1, y);//down
				do_findvirus(x + 1, y + 1);//right down
			}
		}
	
	}
	
private:
	std::vector<std::vector<Cell>> cellsgroup;
	std::vector<std::vector<Cell>> cellsgroup_check;
	int numberofVirus_check;
	int units;
};