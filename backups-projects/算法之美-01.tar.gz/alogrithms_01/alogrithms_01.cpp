//// alogrithms_01.cpp : �������̨Ӧ�ó������ڵ㡣
////
//
//#include "stdafx.h"
//#include <cstdio>
////#include <cmath>
//#include <iostream>
//#include <fstream>
//#include <iomanip>
//#include <memory>
//#include "alogrithms_string_mp.h"
//#include <string>
//#include "problems.h"
//#include "DoubleCirList.hpp"
//#include <algorithm>
//#include <numeric>
////#include <assert.h>
//#include "StackList.hpp"
//#include "CarMgr.h"
//#include "Queue.hpp"
//#include "Maze.h"
//#include "Queen.h"
//#include "BinaryTree.h"
//#include "Tree.hpp"
//#include "Huffman.h"
//#include "Graph.h"
//#include "GraphArray.h"
//#include "HeapArray.hpp"
//#include <cmath>
//#include "BinarySearchTree.hpp"
//#include "Set.hpp"
//#include <istream>
//#include "Hash.hpp"
//#include "WordsCheck.h"
//#include "DisjointSet.h"
//#include "sort.h"
//#include <random>
////#include <windows.h>
//#include "GraphList.h"
//#include "ThreadBinaryTree.h"
//#include "search.h"
//#include "UnionFind.hpp"
//using namespace std;
//int main()
//{
//	LinkQueueList<int> qu;
//	for (int i = 0; i < 10; ++i)
//		qu.EnQueue(i);
//	while (!qu.isEmpty())
//		printf("%d ", qu.DeQueue());
//	printf("\n");
//	system("pause");
//	/*
//	UnionFind<int> uf(12);
//	uf.Union(9, 7);
//	uf.print_ids();
//	uf.Union(7, 5);
//	uf.Union(5, 3);
//	uf.print_ids();
//	uf.Union(3, 0);
//	uf.Union(10, 8);
//	uf.print_ids();
//	uf.print();
//	bool f1 = uf.find(11, 5);
//	bool f2 = uf.find(0, 5);
//	*/
//	
//	/* ������
//	ThreadBinaryTreeSearchList<int> tbtsl(20);
//	tbtsl.insert(tbtsl.getRoot(), 30);
//	tbtsl.insert(tbtsl.getRoot(), 10);
//	tbtsl.insert(tbtsl.getRoot(), 5);
//	tbtsl.insert(tbtsl.getRoot(), 15);
//	tbtsl.insert(tbtsl.getRoot(), 16);
//	tbtsl.insert(tbtsl.getRoot(), 17);
//	tbtsl.insert(tbtsl.getRoot(), 18);
//	tbtsl.insert(tbtsl.getRoot(), 33);
//	tbtsl.erase(tbtsl.getRoot(), 15);
//	tbtsl.Threading_InOrder();
//	tbtsl.InOrder_Traverse_usingThread();
//	*/
//	 //int arr[] = { 7,9,0,-9,0,12,10,5,3,50 };
//	//int find1=fibnonacci_find<int>(arr, 1, 10, 29);
//	 //int find2 = insert_find<int>(arr, 22, 0, 10);
//	 //int sz = sizeof(arr) / sizeof(arr[0]);
//	// insert_sort<int>(arr, sz);
//	// binarysort<int>(arr, sz);
//	// HeapSort<int>(arr, sz);
//	 //MergeSortRescursion<int>(arr, sz);
//	 //QuickSort<int>(arr, sz);
//	 //QuickSort5_MinRescursion<int>(arr, sz);
//	//GraphMartix gm(true);
//	//gm.Find_MinPath_Dijkstra();
//	//gm.Find_MinPath_Floyd();
//
//	//system("pause");
//	return 0;
//	/*���ӱ�ʾ�������ı���
//	
//	TreeList<int> tl(20);
//	tl.insertChild(tl.getRoot(), 22);
//	tl.insertChild(tl.getRoot(), 99);
//	tl.insertChild(tl.getRoot(), 111);
//	tl.insertChild(tl.getRoot(), 777);
//	tl.insertChild(tl.getRoot()->getLeftchild(), 55);
//	tl.insertChild(tl.getRoot()->getLeftchild()->getRightSlibing()->getRightSlibing(), 102);
//	tl.insertChild(tl.getRoot()->getLeftchild()->getRightSlibing()->getRightSlibing(), 103);
//	tl.insertChild(tl.getRoot()->getLeftchild()->getRightSlibing()->getRightSlibing()->getRightSlibing(), 779);
//	//tl.do_traverse_PreOrder_recursion(tl.getRoot());
//	//tl.do_traverse_PreOrder(tl.getRoot());
//	tl.do_traverse_PostOrder_recursion(tl.getRoot());
//	*/
//	/*�Ǹ�ʱ
//	const int maxsz = 100000;
//	int arr[maxsz];
//	int a2[maxsz];
//	int sz = sizeof(arr) / sizeof(arr[0]);
//	std::uniform_int_distribution<int> u(-100,100);
//	std::default_random_engine e;
//	for (int i = 0; i < sz; ++i)
//	{
//		arr[i] = u(e);
//	}
//	cout << "����������ʱ��" << (getRunningTime<int, decltype(binarysort<int>)>(arr, sz, binarysort))<<"��";
//	*/
//	
//	//insert_sort<int>(arr, sz);
//	//binarysort<int>(arr, sz);
//	//shellSort<int>(arr, sz);
//	//directSelectSort<int>(arr, sz);
//	//BubbleSort<int>(arr, sz);
//	//ShakerSort(arr, sz);
//	//QuickSort(arr, sz);
//	//QuickSort4(arr, sz);
//	//MergeSort<int>(arr, sz);
//	//CountingSort(100,arr, sz);
//	/* ���鼯
//	DisjointSet<int> dis(10, {0,1,2,3,4,5,6,7,8,9 });
//	dis.setUnion(0,1);
//	dis.setUnion(2,3);
//	dis.setUnion(4,1);
//	dis.setUnion(3,5);
//	dis.setUnion(1, 5);
//	dis.setUnion(7,6);
//	dis.setUnion(8, 6);
//	dis.setUnion(0, 5);
//	dis.setUnion(1, 3);
//	dis.print();
//	*/
//	/*
//	HashTable<EnglishWord, decltype(EnglishWord_Hash)> hash(EnglishWord_Hash ,53);
//	hash.insert(string("fb"));
//	hash.insert(string("fsbbfd"));
//	auto j=hash.find(string("fb"));
//	hash.print();
//	*/
//	//WordCheck_HashStored wd(string("wordlist.txt"));
//	//wd.demo_mode();
//	/*
//	HashSet < EnglishWord, decltype(EnglishWord_Hash), decltype(eq) > td(EnglishWord_Hash, eq);
//	td.insert(string("dsvds"));
//	td.insert(string("svsvs"));
//	td.insert(string("dsfgsdgdsdsfds"));
//	auto j = td.getKeysCount();
//	*/
//	
////WordsCheck wc;
////wc.demo_mode();
//	/*��������
//	string fn = "topologicalsort\\notdag.txt";
//	GraphMartix gm(fn, true);
//	gm.TopologicalSort_Khan();
//	gm.TopologicalSort_DFS();
//	*/
//	/*��������
//	int arr[] = { 49,38,65,97,76,13,27,49 };
//	QuickSort(arr, sizeof(arr) / sizeof(arr[0]));
//	*/
//	/*��������
//int arr[] = { 10,89,123,7,4,500,444,32 };
//	int sz = sizeof(arr) / sizeof(arr[0]);
//	RadixSort(arr, sz,4);
//	*/
//	//GraphList gl(false);
//	//gl.FindMinWeightPath_Dijkstra(8,0);
//	//gl.MST_Prim(3);
//	//gl.MST_Kruskal();
//	//gl.TopologicalSort();
//	//gl.TopologicalSort_DFS();
//	//gl.CriticalSort();
//	//GraphMartix gnd(true);
//	//gnd.CriticalSort();
//	//gl.FindMinWeightPath_Dijkstra(0);
//	//gnd.Find_MinPath_Dijkstra();
//	//gnd.MST_Prim(3);
//	//gnd.MST_Kruskal();
//	//gnd.TopologicalSort_Khan();
//
//
//}
////float f = 2.5;
////printf("%c", f);
///* ������õ�ͼ�Ĵ洢
//Graph d;
//Vertex v1("a");
//Vertex v2("b");
//Vertex v3("c");
//Vertex v4("d");
//Vertex v5("e");
//Vertex v6("f");
//Edge e1("e1", &v1, &v2);
//Edge e2("e2", &v2, &v3);
//Edge e3("e3", &v3, &v4);
//Edge e4("e4", &v4, &v5);
//Edge e5("e5", &v5, &v1);
//
//Graph d2;
//Edge e2_6("e6", &v5, &v2);
//Edge e2_7("e7", &v1, &v5);
//Edge e2_8("e8", &v5, &v6);
//
//d.insertVertex(v1);
//d.insertVertex(v2);
//d.insertVertex(v3);
//d.insertVertex(v4);
//d.insertVertex(v5);
//d.insertEdge(e1);
//d.insertEdge(e2);
//d.insertEdge(e3);
//d.insertEdge(e4);
//d.insertEdge(e5);
//
//d2.insertVertex(v1);
//d2.insertVertex(v2);
//d2.insertVertex(v5);
//d2.insertVertex(v6);
//d2.insertEdge(e1);
//d2.insertEdge(e2_6);
//d2.insertEdge(e2_7);
//d2.insertEdge(e2_8);
//Graph un = union_Graph(d, d2);
//Graph in = intersection_Graph(d, d2);
//Graph com = complementary_Graph(d, d2);
//
//cout << "Graph1:" << endl;
//d.print_detail();
//cout << "Graph2:" << endl;
//d2.print_detail();
//cout << "UNION : " << endl;
//un.print_detail();
//cout << "INTERSECTION : " << endl;
//in.print_detail();
//cout << "COMPLEN : " << endl;
//com.print_detail();
//*/
///* �ڽӾ���洢��ͼ��ʹ��
//GraphMartix gnd(true);
//gnd.print();
////if (!gnd.Eulercircle()) { cout << "��"; }
////cout << "����һ���Բ��ظ�����";
//gnd.DFSTraverse("A");
//*/
////������Ϸ PlaysOnWord();
///* ��̤����
//Board bd;
//
//int x, y;
//cin >> x >> y;
////bd.findPath_digui(x, y);//����ǵݹ鷨 ����
//bd.findPath_tanxin(x, y);//�����̰���㷨�Ż���
////bd.print();
//*/
////GraphMartix gr(string("graph_martix.txt"));
////vector<int> ss;
////gr.Find_MinPath_Floyd();
////gr.Find_MinPath_Dijkstra();
////cout << "Kruskal�㷨��\n";
////gr.MST_Kruskal();
////cout << "Prim�㷨����������ʼ�����꣺";
////int n;
////cin >> n;
////gr.MST_Prim(n);
//
///* AVL
//BinarySearchTree<int> bt(18);
//auto j = bt.getRoot();
////bt.insert(j, 18);
//bt.insert(j, 19);
//bt.insert(j, 22);
//bt.insert(j, 17);
//bt.insert(j,11);
//bt.insert(j, 10);
//bt.insert(j, 15);
//bt.insert(j, 13);
//bt.remove(j, 11);
//AVLTree<int> avl(4);
//for (int i = 5; i <= 10000; ++i)
//avl.insert( i);
//
//*/
////system("pause");
///* AVL��LLRB��
//RBTree<int> rb(1);
//AVLTree<int> avl(1);
//for (int i = 2; i <= 10; ++i)
//
//{
//rb.insert(i);
//avl.insert(i);
//}
//rb.InOrderTraverse(rb.getRoot());
//avl.InOrderTraverse(avl.getRoot());
////rb.InOrderTraverse(rb.getRoot());
////cout << endl;
//*/
///* trie����ʹ��
//int a, b;
//a = (b = 4) = 5;
//TrieTree<> ch;
//ch.insert("abc");
//ch.insert("abcdf");
//ch.insert("abc");
//ch.insert("abcdef");
//ch.insert("abcde");
//ch.insert("bcd");
//ch.insert("bcb");
//string d("abcdef");
//ch.printAll();
//cout << "abǰ׺��";
//ch.printPre("a");
//*/
///*
//VectorSet set1(7);
//VectorSet set2(7);
//VectorSet set3(7);
//set1.add(1);
//set1.add(3);
//set1.add(5);
//set1.add(6);
//set2.add(1);
//set2.add(2);
//set2.add(3);
//cout << set1;
//cout << set2;
//cout << set3;
//cout << set1 + set2;
//cout << set1 - set2;
//ListSet<int> ls, ls2;
//ls.add(1);
//ls.add(3);
//ls.add(88);
//ls2.add(8);
//ls2.add(1);
//ls2.add(3);
//ls2.add(88);
//bool l = ls2 == ls;
//ListSet<int> ls3(ls);
//cout << "---------------------------\n";
//cout << "����ls��" << ls << "����ls2��" << ls2 << "����ls3��" << ls3;
//cout<<"ls��ls2"<<ls + ls2;
//cout<<"ls3-ls��ls2"<<ls3 - ls *ls2;
//*/
///*�ֵ��ʹ��
//Dictionary di("llrb_wordlist.txt");
//string sl;
//
//string f;
//string res;
//while (1)
//{
//cout << "���������ĵ���(����q�˳�)��";
//cin >> sl;
//if (sl == string("q") || sl == string("Q"))
//break;
//res = di.findChinese(sl);
//if (res.empty())
//{
//cout << "û�н�����Ƿ�Ϊ�����ӵ��ֵ��У�(Y/N)";
//cin >> f;
//if (f == string("Y") || f == string("y"))
//{
//
//string chs;
//cout << "������������ʵ�������˼��";
//getchar();//ɾ��������Ļس�
//char t;
//while ((t = getchar()) != '\n')
//chs.push_back(t);//��Ҫ��Ϊ�˿��Բ�����ո�
//di.insert(sl, chs);
//di.insertToFile(sl, chs, "llrb_wordlist.txt");
//cout << "����ɹ���" << endl;
//}
//}
//else
//{
//cout << "������˼Ϊ��" << res<<endl;
//}
//}
//*/
///*
//string keys[] = {
//"auto","amd","alike",
//"bbc","big",
//"city","cinema","crime",
//"double",
//"zippod",
//"feature"
//};
//int sz = sizeof(keys) / sizeof(keys[0]);
//const int MAXSIZE = 101;
//int count[MAXSIZE];
//memset(count, 0, MAXSIZE * sizeof(int));
//int pos;
//for (int i = 0; i < sz; ++i)
//{
//pos = BKDRHash(keys[i], MAXSIZE);
//count[pos]++;
//}
//cout << "BKDR Hash����������\n";
//for (int i = 0; i < sz; ++i)
//{
//pos = BKDRHash(keys[i], MAXSIZE);
//cout << keys[i] << "  Position is "<<pos<<"  HASH ID IS : " << count[pos] << endl;
//}
//cout << "\nFNV Hash����������\n";
//for (int i = 0; i < sz; ++i)
//{
//cout << "����\"" << keys[i] << "\" Hash��λ����" << std::hex << std::showbase << FNV1A_32_Hash(keys[i]) << endl;
//}
//cout << "\nFNV Hash(�Ż��汾)����������\n";
//for (int i = 0; i < sz; ++i)
//{
//cout << "����\"" << keys[i] << "\" Hash��λ����" << std::hex << std::showbase << FNV1A_32_Hash_Optimize(keys[i]) << endl;
//}
//HashNode<int> kdfdf(5);
//*/
///*
////HashTable<EnglishWord, decltype(EnglishWord_Hash)> dict(EnglishWord_Hash, 53);
//
//auto lab = [](int &num)->int {return num % 10; };
//HashTable<int, decltype(lab)> hash(lab, 13);
//hash.insert(41);
//hash.insert(31);
//hash.insert(21);
//hash.insert(22);
//hash.print();
//hash.insert(41);
//auto j = hash.find(51);
//auto i = hash.find(41);
//
//*/
///*�Ľ���Z�ֱ���
//const int d1 = 6;
//const int d2 =6;
//int martix[d1][d2];
//int martix2[d1][d2];
//int *p=&martix[0][0];
//for (int u = 0; u < d1*d2; ++u)
//*p++ = u;
//cout << "ԭʼ������: " << endl;
//for (int u = 0; u < d1; ++u)
//{
//for (int j = 0; j < d2; ++j)
//{
//std::cout << setw(4) << martix[u][j];
//}
//std::cout << endl;
//}
//int u = 0, j = 0;//XY����һ��������
//int x, y;
////z���ͱ���
//for (x = 0; x < d1; ++x)
//{
//for (y = 0; y < d2; ++y)
//{
//martix2[u][j] = martix[x][y];
////u�������� j�Ǻ�����
//if ((d1 % 2==0 && j % 2 == 0 && (u == 0 || u == d1 - 1)) || (d1 % 2  && (u ==0 && j %2==0 && j !=d1-1|| u==d1-1 && j %2==1) ))//��ֹ�����϶˵������
//{
//j++;
//continue;
//}
//if ((d1%2==0 && u % 2 == 1 && (j == 0 || j == d2 - 1)) || (d1 % 2 && (j==d2-1 && u %2 ==0||u %2==1 &&  j==0)))
//{
//u++;
//continue;
//}
//if ( (u + j) % 2 == 0)
//{
//j++;
//u--;
//}
//else
//{
//u++;
//j--;
//
//}
//}
//}
//cout << "�޸ĺ������: " << endl;
//for (int u = 0; u < d1; ++u)
//{
//for (int j = 0; j < d2; ++j)
//{
//std::cout << setw(4) << martix2[u][j];
//}
//std::cout << endl;
//}
//*/
///*
//cout << "������÷��Ĵ�Сn��n��һ������1����������";
//int n = 1;
//cin >> n;
//cout << endl;
//int **a = new int*[n];
//for (int i = 0; i<n; ++i) {
//a[i] = new int[n];
//memset(a[i], 0, n * sizeof(int));
//}
//
//int row = 0;
//int col = n / 2;
//
//for (int i = 1; i <= n*n; i++) {
//a[row][col] = i;
//row--;
//col++;
//
//if (row<0 && col >= n)
//{
//col--;
//row += 2;
//}
//else if (row<0)
//{
//row = n - 1;
//}
//else if (col >= n)
//{
//col = 0;
//}
//else if (a[row][col] != 0)
//{
//col--;
//row += 2;
//}
//}
//for (int i = 0; i<n; i++)
//{
//for (int j = 0; j<n; j++)
//{
//cout << setw(6) << a[i][j];
//}
//cout << endl;
//}
//
//for (int i = n; i > 0;)
//delete[] a[--i];
//delete[] a;
//*/
////��ͨģʽ�ľŹ����㷨
///*
//int line;
//std::cout << "�����������:";
//std::cin >> line;
//int **arr = new int*[line];
//for (int i = 0; i < line; ++i)
//{
//arr[i] = new int[line];
//for (int j = 0; j < line; ++j)
//{
//arr[i][j] = 0;
//}
//}
//delete[] arr;
//*/
////std::string s = "bcdabcdef"; std::string p = "abcdefbcd";
////std::cout << find_using_BMH(s.c_str(), p.c_str(), s.size(), p.size());
////huisu_mohu_alogrithms(s.c_str(), p.c_str(), s.size(),p.size());
////int j=jos(2,16900);
////int u = jos2(2,16900);
////realease_poker();
////latin_pattern_1(4);
///* �������Ǽ���
//char ch[14] = { 'y','o','u','a','r','e','i','n','d','a','n','g','e','r' };
//int key[6] = { 6,9,8,5,9,2 };
//Vigenere_classfiy(ch, key, 14, 6);
//*/
///*
//DoubleCirList<int> dl;
//for (int j = 1; j <= 20; ++j)
//dl.push_back(j);
//for (auto beg = dl.begin(); beg != dl.end(); ++beg)
//std::cout << *beg << std::endl;
////int acc = std::accumulate(beg, end, 0);
//
//auto b = dl.begin();
//++b; ++b; ++b;
//dl.erase(b);
//for (auto beg = dl.begin(); beg != dl.end(); ++beg)
//std::cout << *beg << std::endl;
//*/
///*
//StackList<int> li;
//for (int u = 1; u <= 10; ++u)
//li.Push(u);
//int j = 1;
//while (j++<=3)
//{
//std::cout << li.TopAndPop() << std::endl;
//}
//
//li.~StackList();
//*/
/////int ggg = getMaxSubSum(g, 0,5);
///* ��λ����ϵͳ��ʹ��
//std::string s = "D:\\�㷨֮��\\alogrithms_01\\Debug\\cars_lot.txt";
//std::ifstream f(s);
//CarManage cm(6, f);
//*/
///*˳�����
//ArrayQueue<int> aq(5);
//for (int i = 1; i <= 20; ++i)
//{
//aq.enQueue(i);
//}
//for (int i = 1; i <= 3; ++i)
//aq.deQueue();
//for (int i = 1; i <= 2; ++i)
//aq.enQueue(i + 22);
//while (!aq.isEmpty())
//{
//std::cout << aq.getFront() << std::endl;
//aq.deQueue();
//}
//*/
///* ��ʽ����
//
//*/
///* �������
//int n;
//std::cout << "������������ǵĽ���:(>=1)";
//cin >> n;
//char d = 'aa';
//char d63 = 'bbb';
//int a = 5, b = 4, c = 3;
//a = (b = 4) = 3;
//Yanghui_Triangle(n);
//Yanghui_Triangle_array(n);
//*/
///* ���ȶ��е�ʹ��
//PriorQueueList<int> pq;
//pq.EnQueue(5);
//pq.EnQueue(4);
//pq.EnQueue(30);
//pq.EnQueue(3);
//pq.EnQueue(0);
//pq.EnQueue(2);
//pq.EnQueue(2);
//pq.EnQueue(1);
////while (!pq.isEmpty())
////{
////	cout << pq.DeQueue() << endl;
////}
//*/
///* �ڴ����ģ��
//int me[] = { 4,3,2,1,4,3,5,4,3,2,1,5 };
//Queyezhongduan(me, 12);
//Queue_memory_pagemgr_LRU(me, 12);
//*/
///* �����׳�
//int n;
//cout << "������һ������n ���ǻ�����1!~n!: ";
//cin >> n;
////display_factorize(n);
//output_factorize(n);
//*/
////��ŵ������ 
////Hannuo(3, 'A', 'B', 'C');
///* ϸ����Ⱦ
//int bb[6][6] = {
//{1,0,0,0,0,0},
//{0,1,0,0,0,0},
//{0,0,1,1,0,1},
//{0,0,1,1,0,1},
//{1,0,1,1,0,1},
//{1,0,0,0,0,0}
//};
//CellsGroup ce(bb, 6);
//ce.find_virus(1, 1);
//ce.display_grid_check();
//*/
///* �Թ����
//std::vector<Crossing> cros;
//Crossing c1(2,0,0);
//Crossing c2(4,0,0);
//Crossing c3(0, 0, 0);
//Crossing c4(5,3,0);
//Crossing c5(6,0,0);
//Crossing c6(0, 7, 0);
//Crossing c7(8,9,0);
//Crossing c8(0, 0, 0);
//Crossing c9(10, 0, 0);
//Crossing c0(0, 0, 0);
//cros.push_back(c0);
//cros.push_back(c1);
//cros.push_back(c2);
//cros.push_back(c3);
//cros.push_back(c4);
//cros.push_back(c5);
//cros.push_back(c6);
//cros.push_back(c7);
//cros.push_back(c8);
//cros.push_back(c9);
//Maze ma(cros, 10);
//ma.FindExit();
//*/
///*  n�ʺ�����
//QueenPuzzle qz(5);
//qz.PlaceQueen(0);
////cout <<QueenPuzzle::sum << endl;
//*/
///*
//BinaryTreeList<int> li(32);
//li.insert_left(li.getRoot(), 5);
//li.insert_left(li.getRoot(), 6);
//li.insert_left(li.getRoot()->getLeftchild(), 7);
//li.insert_right(li.getRoot()->getLeftchild(), 10);
//li.insert_right(li.getRoot(), 55);
//li.insert_right(li.getRoot(), 66);
//li.insert_left(li.getRoot()->getRightchild(), 22);
////ǰ�����
//cout << "Preorder traverse : ";
//li.PreOrder(li.getRoot());
//cout << endl << "Preorder traverse using stack : ";
//li.PreOrder_Stack(li.getRoot());
//cout << "Inorder traverse : ";
//li.InOrderTraverse(li.getRoot());
//cout << endl << "Inorder traverse using stack : ";
//li.InOrderTraverse_Stack(li.getRoot());
//cout << "Post traverse : ";
//li.PostOrderTraverse(li.getRoot());
//cout << endl << "Postorder taverse using stack :";
//li.PostOrderTraverse_Stack(li.getRoot());
//cout << "LevelOrder Traverse : ";
//li.LevelOrderTraverse(li.getRoot());
////������
//cout << endl;
////li.PreOrderThread(li.getRoot());
////li.Display_PreOrderThread(li.getRoot());
//li.PostOrderThread(li.getRoot());
//li.Display_PostOrderThread(li.getRoot());
//
////li.InOrderThread(li.getRoot());
////li.Display_InOrderThread(li.getRoot());
////li.Display_PreOrderThread(li.getRoot());
//*/
///* ��ͨ����
//TreeList<int> li(66);
//li.insertChild(li.getRoot(), 5);
//li.insertChild(li.getRoot(), 6);
//li.insertChild(li.getRoot(), 7);
//li.insertChild(li.getRoot()->getLeftchild(), 99);
//auto l = li.getRoot()->getLeftchild();
//li.clear();
//*/
///* �����������ʹ��
//const char *c; int sz;
//cout << "������Ҫ��������У�";
//std::string s;
//cin >> s;
//c = s.c_str();
//sz = s.size();
//Huffman hmf;//����������
//Huffman::Charfrenquent hmf_freq;//�ַ����ֵ�Ƶ��
//hmf.calcFrenquentofChars(c,sz,hmf_freq);
//HuffmanTreeNodeBase *tree = hmf.buildHuffmanTree(hmf_freq);//�õ��ع�������
//Huffman::CharMap hmf_map;//������ӳ���
//hmf.genrateCode(tree, hmf_map,hmf_freq);
//delete tree;
//int orgsz = 0;
//int zipsz = 0;
//
////����Ӧ�õĳ���
//int cnt = 0;
//int weight = 1;
//int t =  hmf_map.size();
//while (1)
//{
//if (t == 1)
//{
//cnt = 1;
//break;
//}
//if (t - weight <= 0)
//{
//break;
//}
//else { weight *= 2; ++cnt; }
//}
////cnt��Ӧ��Ҫ����Ķ����Ƶ�λ��
//orgsz = sz*cnt;
//cout << endl<<"��õĹ���������ӳ��Ϊ��"<<endl;
//for (auto i = hmf_map.cbegin(); i != hmf_map.cend(); ++i)
//{
//cout << "[" << i->first << "]=";
//for (int j = 0; j < (i->second).size(); ++j)
//{
//cout << i->second[j];
//
//}
//cout << endl;
//}
//std::string  hfm_encodedstr;//�����ʾ�����������Ķ�����
//cout <<"�õ��Ĺ������ַ�����Ϊ��";
//for (int i = 0; i < sz; ++i)
//{
//for (int j = 0; j < hmf_map[c[i]].size(); ++j)
//{
//cout << hmf_map[c[i]][j];
//hfm_encodedstr.push_back(hmf_map[c[i]][j]+'0');
//++zipsz;//ѹ�����С����
//}
//cout << " ";
//}
//cout << endl << "ԭʼ���볤�ȣ�" << orgsz << "������󳤶ȣ�" << zipsz << " ѹ����Ϊ��" << (static_cast<float>(zipsz) / orgsz) << endl;
//cout << "�����" << hmf.deCoding(hmf_map, hfm_encodedstr)<<endl;//���½���
//*/
///* �ѵ�ʹ��
//HeapArray<int,std::greater<int>> hn(10,std::greater<int>());
//hn.insert(10);
//hn.insert(40);
//hn.insert(30);
//hn.insert(60);
//hn.insert(90);
//hn.insert(70);
//hn.insert(20);
//hn.insert(50);
//hn.insert(80);
//hn.insert(85);
//hn.insert(90);
//int sz = hn.getSize();
//for (int i = 0; i < sz; ++i)
//cout << hn.TopandPop() << endl;
//*/
//




#include "stdafx.h"
#include "Queue.hpp"
int main()
{
	LinkQueueList<int> qu;
	for (int i = 0; i < 10; ++i)
		qu.EnQueue(i);
	
	while (!qu.isEmpty())
		printf("%d ", qu.DeQueue());
	printf("\n");
	system("pause");
}