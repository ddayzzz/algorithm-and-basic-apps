// CA4.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "AVLTree.h"

int main()
{
	AVLTree a;
	//a = make_empty_avltree();
	a = NULL;
	for (int i = 1; i <= 1000; ++i)
	{
		a = insert_avltree(i, a);
	}
	print_all_elements_avltree(a);
	//getchar():
	free_avltree(a);
    return 0;
}

