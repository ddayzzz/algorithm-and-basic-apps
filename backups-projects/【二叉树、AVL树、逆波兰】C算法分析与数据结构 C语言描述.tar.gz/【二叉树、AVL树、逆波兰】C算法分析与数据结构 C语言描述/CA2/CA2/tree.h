#pragma once
#include "stdafx.h"
typedef int elementtype;
struct BTreeNode
{
	elementtype data;
	BTreeNode *left;
	BTreeNode *right;
};
typedef BTreeNode *PtrToBTreeNode;
typedef PtrToBTreeNode BinaryTree;
BinaryTree create_binarytree()
{

}