#pragma once
#include "stdafx.h"
typedef int elementtype_btree;
struct BTreeNode
{
	elementtype_btree data;
	BTreeNode *left;
	BTreeNode *right;
};
typedef BTreeNode *PtrToBTreeNode;
typedef PtrToBTreeNode Position;
typedef PtrToBTreeNode SearchTree;
SearchTree create_binarytree(elementtype_btree data)
{
	SearchTree sr = (SearchTree)malloc(sizeof(BTreeNode));
	sr->left = sr->right = NULL;
	sr->data = data;
	return sr;
}
Position find(elementtype_btree x, SearchTree s)
{
	if (s == NULL)
	{
		return NULL;
	}
	else
	{
		if (x < s->data)
		{
			return find(x, s->left);
		}
		else
		{
			if (x > s->data)
			{
				return find(x, s->right);
			}
			else
			{
				return s;
			}
		}

	}
}
Position findMin(SearchTree s)
{
	if (s == NULL)
	{
		return NULL;
	}
	else
	{
		if (s->left == NULL)
		{
			return s;
		}
		else
		{
			return findMin(s->left);
		}
	}
}
Position findMax(SearchTree s)
{
	if (s != NULL)
		while (s->right != NULL)
			s = s->right;
	return s;
}
SearchTree insert(elementtype_btree e, SearchTree s)
{
	if (s == NULL)
	{
		s = (SearchTree)malloc(sizeof(BTreeNode));
		s->data = e;
		s->left = s->right = NULL;
	}
	else
	{
		if (e < s->data)
		{
			s->left = insert(e, s->left);
		}
		else
		{
			if (e > s->data)
			{
				s->right = insert(e, s->right);
			}
		}
	}
	return s;
}
SearchTree deletetreenode(elementtype_btree e, SearchTree s)
{
	if (s != NULL)
	{
		Position pos;
		if (e < s->data)
		{
			//left
			s->left=deletetreenode(e, s->left);
			
		}
		else
		{
			if (e > s->data)
			{
				//right
				s->right=deletetreenode(e, s->right);
			}
			else
			{
				//��Ҫ��ɾ����node 
				if (s->left != NULL && s->right != NULL)
				{
					//�������ӽڵ� pos��leftһ��ΪNULL
					pos = findMin(s->right);
					s->data = pos->data;
					s->right = deletetreenode(s->data, s->right);//
				}
				else
				{
					//one or zero subtree
					pos = s;
					if (s->left == NULL)
						s = s->right;
					else if (s->right == NULL)
						s = s->left;
					free(pos);
				}
			}
		}
	}
	return s;
}
void printtree_node(SearchTree s, int depth)
{
	for (int i = 0; i < depth; ++i)
	{
		
		printf("|  ");//����
	}
	printf("|-<%d>\n", s->data);
}
void printree(SearchTree s,int depth)
{
	printtree_node(s, depth);
	if (s->left != NULL)
	{
		printree(s->left, depth + 1);
	}
	if (s->right != NULL)
	{
		printree(s->right, depth + 1);
	}

}
void freeroot(SearchTree  root)
{
	if (root != NULL)
	{
		freeroot(root->left);
		freeroot(root->right);
		free(root);
	}
}
elementtype_btree retrieve(Position p)
{
	return 0;
}