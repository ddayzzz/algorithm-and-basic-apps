#pragma once
#include "Stack_array.h"

char* infixToposfix(char *c, int size)
{
	Stacka sa_ops;
	sa_ops = create(size+1);
	char *res = (char*)malloc(size * sizeof(char)); int index = 0;
	int u = 0;
	for (; u < size; ++u)
	{
		if ((c[u] >= '0' && c[u] <= '9') || (c[u] >= 40 && c[u] <= 43) || c[u] == '-' || c[u] == '/' || c[u]=='^'/*ȡ������*/)
		{
			switch (c[u])
			{
			case '(':
				push(c[u], sa_ops);
				break;
			case '^':
				push(c[u], sa_ops);
				break;
			case ')':
				if (u <= 2) {/*�������ǳ�����*/}
				else
				{
					while (top(sa_ops) != '(')
					{
						//printf("%c", top(sa_ops));
						res[index++] = top(sa_ops);
						pop(sa_ops);
					}
					pop(sa_ops);
				}
				break;
			case '+':
				if (u <= 0) {/*�������ǳ�����*/ }
				else
				{
					while (top(sa_ops) !=NULLVALUE && top(sa_ops) != '(')
					{
						//printf("%c", top(sa_ops));
						res[index++] = top(sa_ops);
						pop(sa_ops);
					}
					push('+', sa_ops);
				}
				break;
			case '-':
				if (u <= 0) {/*�������ǳ�����*/ }
				else
				{
					while (top(sa_ops) != NULLVALUE && top(sa_ops) != '(')
					{
						//printf("%c", top(sa_ops));
						res[index++] = top(sa_ops);
						pop(sa_ops);
					}
					push('-', sa_ops);
				}
				break;
			case '*':
				if (u <= 0) {/*�������ǳ�����*/ }
				else
				{
					while (top(sa_ops) != NULLVALUE && top(sa_ops) != '(')
					{
						if (top(sa_ops) == '+' || top(sa_ops) == '-')
						{
							break;
						}
						else
						{
							//printf("%c", top(sa_ops));
							res[index++] = top(sa_ops);
							pop(sa_ops);
						}
					}
					push('*', sa_ops);
				}
				break;
			case '/':
				if (u <= 0) {/*�������ǳ�����*/ }
				else
				{
					while (top(sa_ops) != NULLVALUE && top(sa_ops) != '(')
					{
						//printf("%c", top(sa_ops));
						res[index++] = top(sa_ops);
						pop(sa_ops);
					}
					push('/', sa_ops);
				}
				break;
			default:
				//printf("%c", c[u]);
				res[index++] = c[u];
				break;
			}
		}
	}
	if (!isempty(sa_ops))
	{
		while (!isempty(sa_ops))
		{
			//printf("%c", top(sa_ops));
			res[index++] = top(sa_ops);
			pop(sa_ops);
		}
	}
	dispose(sa_ops);
	res[index] = '\0';
	return res;
	
}
//ĿǰcalcûŪ�� ������ģ����Ū
void calc(char *expr,int size)
{
	double res = 0.0;
	char *pos = infixToposfix(expr, size);
	if (pos != NULL)
	{
		Stacka sta;
		sta = create(size);
		int h;
		char num;
		int d1 = 0;
		int d2 = 0;
		for (h = 0; h < size; ++h)
		{
			num = pos[h];
			switch (num)
			{
			case '+':
				if (!isempty(sta) && sta->IndexOfTopStack >= 2)
				{
					d1 = (double)(top(sta)); pop(sta);
					d2 = (double)(top(sta));
					//push()
				}
				break;
			default:
				break;
			}
		}
	}
}