#pragma once
#include "stdafx.h"
typedef struct NodeforStack *PtrtoNode;
typedef PtrtoNode Stack;
typedef int eletype;
//����һ����ջ
struct NodeforStack
{
	NodeforStack *next;
	int data;
};
Stack create(void)
{
	Stack s = (Stack)malloc(sizeof(struct NodeforStack));
	if (s != NULL)
	{
		s->next = NULL;
		return s;
	}
}
int isempty(Stack s) {
	if (s != NULL)
	{
		return s->next == NULL;
	}
	else
	{
		return 1;
	}
}
void pop(Stack s)
{
	if (s != NULL)
	{
		if (isempty(s))
		{
			//�յ�ջ
		}
		else
		{
			PtrtoNode pn;
			pn = s->next;
			s->next = s->next->next;
			free(pn);
		}
	}
}
eletype top(Stack s)
{
	if (!isempty(s))
	{
		return s->next->data;
	}
}
void push(Stack s,eletype t){
	if (s != NULL)
	{
		PtrtoNode p = (PtrtoNode)malloc(sizeof(struct NodeforStack));
		if (p != NULL)
		{
			p->data = t;
			p->next = s->next;
			s->next = p;
		}

   }
}
void disposeStack(Stack s)
{
	if (s != NULL && isempty(s) != 1)
	{
		while (isempty(s) !=1)
		{
			pop(s);
		}
		//free(s);
	}
}
