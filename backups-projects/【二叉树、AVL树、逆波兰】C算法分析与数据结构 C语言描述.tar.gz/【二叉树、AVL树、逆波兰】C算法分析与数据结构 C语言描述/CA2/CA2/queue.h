#pragma once
#include "stdafx.h"
#include <stdlib.h>
typedef int eletype;
struct QueueRecord
{
	int capacity;
	int head;
	int rear;
	int current_size;
	eletype *qarray;
};
typedef struct QueueRecord *Queue;
Queue create_queue(int size)
{
	if (size > 0)
	{
		eletype* a = (eletype*)malloc(sizeof(eletype) * size);
		Queue q = (Queue)malloc(sizeof(struct QueueRecord));
		q->capacity = size;
		q->current_size = 0;
		q->head = 1;
		q->qarray = a;
		q->rear = 0;
		return q;
	}
	else
	{
		return NULL;
	}
}
int isempty(Queue q)
{
	if (q == NULL)
	{
		return 0;
	}
	else
	{
		return q->current_size == 0;
	}
}
int isfull(Queue q)
{
	if (q == NULL)
	{
		return 0;
	}
	else
	{
		return q->current_size == q->capacity;
	}
}
int check_rear_head(int currhead,Queue q)
{
	if (!isempty(q))
	{
		if (++currhead == q->capacity)
		{
			return 0;
		}
		else
		{
			return currhead;
		}
	}
	else
	{
		return currhead;
	}
}
void enqueue(eletype e, Queue q)
{
	if (q !=NULL)
	{
		q->current_size++;
		q->rear = check_rear_head(q->rear,q);
		q->qarray[q->rear] = e;
	}
}
eletype dequeue(Queue q)
{
	if (!isempty(q))
	{
		q->current_size--;
		eletype e = q->qarray[q->head];
		if (check_rear_head(q->head, q))
		{
			q->head++;
		}
		else
		{
			q->head = 0;
		}
		return e;
	}
	else
	{
		return 0;
	}
}
void disopse_queue(Queue q)
{
	if (q != NULL)
	{
		free(q->qarray);
		free(q);
	}
}