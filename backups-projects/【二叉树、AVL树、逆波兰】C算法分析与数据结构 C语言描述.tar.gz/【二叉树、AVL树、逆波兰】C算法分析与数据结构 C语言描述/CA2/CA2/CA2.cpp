// CA2.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <conio.h>
#include "list.h"
//#include "polynomial.h"
#include "polynomial_mangage.h"
//#include "stack.h"
#include "Stack_array.h"
#include "infixtoposfix.h"
#include "queue.h"
#include <iostream>
#include <istream>
#include <string>
#include <vector>
#include <algorithm>
#include "funnytree_filesystemh.h"
#include "binary_sort_binarytree.h"
const unsigned int  MAXSIZE = 20;
const unsigned int MAXSIZE_OFXISHU =20;
static int getMaxSubSum(const int A[], int left, int right);
static int count = 1;
void input(polynomial_manage *poly,bool initial=true)
{
	//�������ʽ�ض�
	int c;
	char endc;
	char contiu = 'y';
	int temparr[MAXSIZE_OFXISHU];
	if (count == MAXSIZE) { printf("����ʽ�洢����%d", count); return; }
	unsigned pos = 0;
	do
	{
		
		printf("������ӳ�����������ϵ��(����������, ������0). ���%d������, ÿ��ϵ����\',\'�ָ�:", MAXSIZE_OFXISHU);
		while ((scanf("%d%c",&c,&endc)) && endc !='\n' && pos <=MAXSIZE_OFXISHU-1)
		{
			temparr[pos] = c;
			++pos;
		}
		temparr[pos] = c;
		int val = 1;
		printf("������δ֪����ֵ:"); scanf("%d", &val); getchar();
		poly->construct_poly(count-1 , val, pos+1, &temparr[0]);
		//poly->get_address_byindex(startindex)->show_unary_mode('\b', 'X');
		printf("�Ƿ����(y/n)?"); contiu = getchar(); 
		if (contiu == 'Y' || contiu == 'y') { ++count; pos = 0; } getchar();
		
	} while (contiu == 'Y' || contiu == 'y');
}

std::string bigplus(std::string left, std::string right)
{
	std::string e1, e2 ;
	for (int j = left.size()-1; j >= 0; --j)
	{
		e1.push_back(left[j]);
	}
	for (int j = right.size() - 1; j >= 0; --j)
	{
		e2.push_back(right[j]);
	}
	if (left.size() < right.size())
	{
		e1.append(std::string(right.size() - left.size(),'0'));
	}
	else
	{
		if(left.size() > right.size()){ e2.append(std::string( left.size() - right.size(),'0')); }
	}
	//okay
	int size = e1.size();
	std::string res(size+1, '0'),fia;
	int addflag=0;
	for (int u = 0; u < size; ++u)
	{
		int r = (e1[u] - '0' + e2[u] - '0');
		int mowei = r % 10;
		addflag = r / 10;
		res[u] = addflag + mowei+48;
	}
	res[size] += addflag;
	for (int j = size; j >= 0; --j)
	{
		if (j == size && res[j]=='0')
		{
			continue;
		}
		else
		{
			fia.push_back(res[j]);
		}
	}
	return fia;
}
void result(std::string  n)
{
	int xiangshu = n.size() / 2;
	int add = n.size() % 2;
	xiangshu += add;
	std::string one = "1";
	std::cout << bigplus(one, n);
}
static int max(int b, int a);

int main()
{	
	/*
	polynomial_manage pom; pom.initial(MAXSIZE);
	input(&pom);
	polynomial *ptp = NULL;
	int k; char unary='X';
	printf("������һ���ַ���ʾδ֪��(����X,y...):");
	unary = getchar();
	getchar();
	for (k = 1; k <= count; ++k)
	{
		 ptp = pom.get_address_byindex(k-1);
		 if (ptp != NULL)
		 {
			 printf("\n���[%d] : ",k);
			 ptp->show_unary_mode('\b', unary);
		 }

	}
	//
	char contiu;
	char ops; unsigned l, r; polynomial *lp = NULL; polynomial  *rp = NULL; polynomial dest;
	do
	{
		printf("\n����������Ҫ�������������ʽ, ����: �����ڶ���͵�����ĳ˻�������2*3 (Ŀǰ֧�ֵ�����+��*):");
		scanf("%d%c%d%*c", &l, &ops, &r);
		if (l > count || r > count)
		{
			printf("����! ����ʽ�ı��̫��.");
			continue;
		}
		switch (ops)
		{
		case '+':
			lp = pom.get_address_byindex(l - 1); rp = pom.get_address_byindex(r - 1);
			if(lp !=NULL && rp !=NULL)
			{
				lp->plus_xishuofpoly(rp, &dest, lp->unknownvalue); printf("(");
				lp->show_unary_mode('\b', unary); printf(")%c(", ops);
				rp->show_unary_mode('\b', unary); printf(")=");
				dest.show_calced_value();
				dest.free_poly();
			}
			break;
		case '*':
			lp = pom.get_address_byindex(l - 1); rp = pom.get_address_byindex(r - 1);
			if (lp != NULL && rp != NULL)
			{
				lp->multiply_xishuopoly(rp, &dest, lp->unknownvalue); printf("(");
				lp->show_unary_mode('\b', unary); printf(")%c(", ops);
				rp->show_unary_mode('\b', unary); printf(")=");
				dest.show_calced_value();
				dest.free_poly();
			}
			break;
		default:
			printf("����! ��֧�ֵ������");
			break;
		}
		printf("����? (y/n)");
		contiu = getchar(); getchar();

	} while (contiu =='Y' || contiu=='y');
	*/
	/*
	Stacka s;
	s = create(5);
	push(2,s);
	push(3,s);
	push(5,s);
	printf("%d]\n", top(s));
	pop(s);
	printf("%d]\n", top(s));
	pop(s);
	printf("%d]\n", top(s));
	pop(s);
	dispose(s);
	int h;
	scanf("%d\n", &h);
	printf("%d", h);
	getchar();
	*/
	;
	/* ��׺ʽתΪ�沨��ʽ
	//fcn(5, 2);
	char l[] = { '1','+','2','*','3','+','(','4','*','5','+','6',')','*','7','\0' };
	int s = sizeof(l) / sizeof(char);
	char *re=infixToposfix(l, s-1);
	printf("%s",re);
	*/
	/* ������е�ʹ��
	Queue q;
	q = create_queue(4);
	enqueue(5, q);
	enqueue(4, q);
	enqueue(2, q);
	enqueue(98, q);
	printf("%d\n", dequeue(q));
	printf("%d\n", dequeue(q));
	printf("%d\n", dequeue(q));
	printf("%d\n", dequeue(q));
	disopse_queue(q);
	*/
	/*
	Node l,r;
	l.makeempty();
	r.makeempty();
	Node dest;
	Node *lp = l.head;
	Node *rp = r.head;
	for (int j = 1; j <= 4; ++j)
	{
		l.insert(j, lp); lp = lp->next;
	}
	for (int j = 3; j <= 6; ++j)
	{
		r.insert(j, rp); rp = rp->next;
	}
	l.intersection(&r, &dest);
	*/
	//std::string s;
	//std::cin >> s;
	//result(s);
	int g[] = { -1,0,5,4,3,1,-2 };
	//int gh = MaxSubQueue_Value(g, 0, 6);
	int ggg = getMaxSubSum(g, 0, 6);
	///* ģ����״�ļ�ϵͳ
	fileobj root, d1, d2,d3, f1, f2, f3;
	root = create_fileordir(0, 'R', 2, 1);
	d2 = create_fileordir(0, '2', 2);
	d1 = create_fileordir(0, '1', 2);
	d3 = create_fileordir(0, '3', 2, 0);
	f2 = create_fileordir(1, 'B', 6);
	f1 = create_fileordir(1, 'A', 6);
	f3 = create_fileordir(1, 'c', 6);
	attachToFather(d3, root);
	attachToFather(d1, root);
	attachToFather(d2, root);
	attachToFather(f1, d2);
	attachToFather(f2, d2);
	attachToFather(f3, d3);
	ListDirectory(root);
	//deletefileobj(d3, root);
	ListDirectory(root);
	printf("-----------------------\n");
	ListDirectory_nameandsize(root);
	freeroot(root);
	//*/
	/*BTreeNode *sorttree;
	sorttree = create_binarytree(236);
	insert(8, sorttree);
	insert(7, sorttree);
	insert(6, sorttree);
	insert(2, sorttree);
	insert(1, sorttree);
	insert(5, sorttree);
	insert(4, sorttree);
	printree(sorttree, 0);
	deletetreenode(6, sorttree);
	printree(sorttree, 0);
	freeroot(sorttree);
	
	*/
	
	getchar();
	return 0;
}
static int max(int b, int a) { return (a > b ? a : b); }
static int getMaxSubSum(const int A[], int left, int right)
{
	//����left right����ȷ����Ѱ�ķ�Χ 
	int i;//ѭ��������
	int maxleftsum, maxrightsum;//���������е��ܺ�
	int leftsum, rightsum;//�������������ܺ�
	int center;
	if (left == right)
	{
		if (A[left] > 0)
			return A[left];
		else
			return 0;
	}
	center = (left + right) / 2;
	maxleftsum = getMaxSubSum(A, left, center);
	maxrightsum = getMaxSubSum(A, center + 1, right);

	maxleftsum = 0; leftsum = 0;
	for (i = center; i >= left; --i)
	{
		leftsum += A[i];
		if (leftsum > maxleftsum) maxleftsum = leftsum;
	}

	maxrightsum = 0; rightsum = 0;
	for (i = center+1; i <=right; ++i)
	{
		rightsum += A[i];
		if (rightsum > maxrightsum) maxrightsum = rightsum;
	}

	return max(max(maxleftsum + maxleftsum, maxleftsum), maxrightsum);
}

