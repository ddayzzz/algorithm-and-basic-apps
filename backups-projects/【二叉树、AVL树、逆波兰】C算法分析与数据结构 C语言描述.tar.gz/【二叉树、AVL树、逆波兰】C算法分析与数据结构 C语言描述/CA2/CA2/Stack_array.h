#pragma once
#include "stdafx.h"
#define MINSIZE 5
#define NULLVALUE -1
typedef char elementtype;



struct Stack_array
{
	int capacity;
	int IndexOfTopStack;
	elementtype *array1;
};
typedef Stack_array *PtrtoStackArray;
typedef PtrtoStackArray Stacka;
PtrtoStackArray create(int maxsize)
{
	PtrtoStackArray pts;
	if (maxsize < MINSIZE)
	{
		//too small
		return NULL;
	}
	else
	{
		pts = (Stack_array*)malloc(sizeof(Stack_array));
		if (pts != NULL)
		{
			pts->array1= (elementtype*)malloc(sizeof(elementtype)*maxsize);
			pts->capacity = maxsize;
			pts->IndexOfTopStack = NULLVALUE;
			return pts;
		}
		else
		{
			return NULL;
		}
	}
}
int isempty(PtrtoStackArray p)
{
	if (p != NULL)
	{
		if (p->array1 != NULL)
		{
			return p->IndexOfTopStack == NULLVALUE;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 0;
	}
}
void push(elementtype e, PtrtoStackArray p)
{
	if (p != NULL)
	{
		if (p->array1 != NULL)
		{
			if (p->IndexOfTopStack < p->capacity - 1)
			{
				p->array1[++(p->IndexOfTopStack)] = e;
			}
		}
	}
}
void pop(PtrtoStackArray p)
{
	if (!isempty(p))
	{
		p->IndexOfTopStack--;
	}
}
elementtype top(PtrtoStackArray p)
{
	if (!isempty(p))
	{
		return (p->array1[p->IndexOfTopStack]);
	}
	else
	{
		return NULLVALUE;
	}
}
void dispose(PtrtoStackArray r)
{
	if (r != NULL)
	{
		free(r->array1);
		free(r);
	}
	else
	{ }
}